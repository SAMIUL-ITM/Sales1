-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 19, 2020 at 06:57 AM
-- Server version: 10.1.10-MariaDB
-- PHP Version: 5.6.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `itm_single_sales`
--

-- --------------------------------------------------------

--
-- Table structure for table `activitylog`
--

CREATE TABLE `activitylog` (
  `activitylog` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `action` varchar(100) NOT NULL,
  `activity_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `activitylog`
--

INSERT INTO `activitylog` (`activitylog`, `userid`, `action`, `activity_date`) VALUES
(618, 22, 'Delete Stuff - Name: Regan', '2019-09-29 09:41:44'),
(619, 22, 'Delete Stuff - Name: ', '2019-09-29 09:41:58'),
(620, 22, 'Delete Stuff - Name: à¦œà§à§Ÿà§‡à¦²', '2020-02-03 14:56:31'),
(621, 22, 'Delete Stuff - Name: à¦®à§‹à¦ƒ à¦à¦¨à¦¾à¦®à§à¦² à¦¹à¦•', '2020-02-03 14:56:35'),
(622, 22, 'Delete Stuff - Name: Jakiul Hasan Ruel', '2020-02-03 14:56:38'),
(623, 22, 'Delete Stuff - Name: Jikrul Hasan Jewel', '2020-02-03 14:56:41'),
(624, 22, 'Delete Stuff - Name: Megh', '2020-02-03 14:56:45'),
(625, 22, 'Update account', '2020-07-18 21:53:28'),
(626, 22, 'Update account', '2020-07-18 21:53:53');

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `brand_id` int(11) NOT NULL,
  `brand_name` varchar(255) NOT NULL,
  `brand_active` int(11) NOT NULL DEFAULT '0',
  `brand_status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`brand_id`, `brand_name`, `brand_active`, `brand_status`) VALUES
(44, 'Samsung', 1, 1),
(45, 'Xiaomi', 1, 1),
(46, 'Huawei', 1, 1),
(47, 'Vivo', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `categories_id` int(11) NOT NULL,
  `categories_name` varchar(255) NOT NULL,
  `categories_active` int(11) NOT NULL DEFAULT '0',
  `categories_status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`categories_id`, `categories_name`, `categories_active`, `categories_status`) VALUES
(57, 'Back Cover', 1, 1),
(58, 'Glass Protector', 1, 1),
(59, 'Charger', 1, 1),
(60, 'Head Phone', 1, 1),
(61, 'Usb Cable', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customer_id` int(30) NOT NULL,
  `member_id` int(50) NOT NULL,
  `customer_no` int(50) NOT NULL,
  `customer_name` varchar(500) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `address` varchar(500) NOT NULL,
  `contact_info` varchar(200) NOT NULL,
  `national_id` varchar(200) NOT NULL,
  `join_date` date NOT NULL,
  `status` int(10) NOT NULL,
  `userPic` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `member_id`, `customer_no`, `customer_name`, `gender`, `address`, `contact_info`, `national_id`, `join_date`, `status`, `userPic`) VALUES
(101, 130, 2, 'Md.Samiul Alom', 'Male', 'Tinmatha', '01751458998', '000', '2020-02-05', 1, '182825.jpg'),
(103, 130, 3, 'New Customer', 'Male', 'Bogura', '01751456623', '00', '2020-08-05', 1, '100997.'),
(104, 130, 4, 'Zobayer2', 'Male', 'Meghai', '01611-717527', '00', '2020-08-10', 1, '179745.');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `id` int(20) NOT NULL,
  `emp_name` varchar(100) NOT NULL,
  `father_name` varchar(100) NOT NULL,
  `national_id` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `contact_info` varchar(50) NOT NULL,
  `birthdate` date NOT NULL,
  `gender` varchar(50) NOT NULL,
  `photo` varchar(200) NOT NULL,
  `position` varchar(200) NOT NULL,
  `hire_date` date NOT NULL,
  `sal_type` varchar(200) NOT NULL,
  `salary` int(200) NOT NULL,
  `status` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `expense`
--

CREATE TABLE `expense` (
  `id` int(20) NOT NULL,
  `user_id` int(100) NOT NULL,
  `expense_name` varchar(300) NOT NULL,
  `expense_cost` varchar(100) NOT NULL,
  `reference` varchar(350) NOT NULL,
  `entry_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `user_id` int(15) NOT NULL,
  `customer_id` int(50) NOT NULL,
  `order_date` date NOT NULL,
  `deliver_date_or_last_update` date NOT NULL,
  `client_name` varchar(255) NOT NULL,
  `client_contact` varchar(255) NOT NULL,
  `sub_total` varchar(255) NOT NULL,
  `vat` varchar(255) NOT NULL,
  `total_amount` varchar(255) NOT NULL,
  `discount` varchar(100) NOT NULL,
  `pre_due` varchar(500) NOT NULL,
  `today_total` varchar(500) NOT NULL,
  `grand_total` varchar(500) NOT NULL,
  `paid` varchar(100) NOT NULL,
  `deliver_date_paid` varchar(220) NOT NULL,
  `due` varchar(255) NOT NULL,
  `dues_or_paid` varchar(30) NOT NULL,
  `dues_or_paid_status` varchar(50) NOT NULL,
  `payment_type` int(11) NOT NULL,
  `payment_status` int(11) NOT NULL,
  `order_status` int(11) NOT NULL DEFAULT '0',
  `order_type` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `user_id`, `customer_id`, `order_date`, `deliver_date_or_last_update`, `client_name`, `client_contact`, `sub_total`, `vat`, `total_amount`, `discount`, `pre_due`, `today_total`, `grand_total`, `paid`, `deliver_date_paid`, `due`, `dues_or_paid`, `dues_or_paid_status`, `payment_type`, `payment_status`, `order_status`, `order_type`) VALUES
(1001, 130, 101, '2020-07-18', '2020-07-18', 'Md.Samiul Alom', '01751458998', '450.00', '0.00', '450.00', '0', '0', '450.00', '450.00', '450', '0', '0.00', 'Dues', '4', 1, 1, 1, 1),
(1002, 130, 0, '2020-08-05', '2020-08-05', 'Kalam', '017518941256', '110.00', '0.00', '110.00', '0', '0', '110.00', '110.00', '50', '0', '60.00', 'Dues', '4', 1, 1, 1, 2),
(1003, 130, 104, '2020-08-10', '2020-08-10', 'Zobayer2', '01611-717527', '750.00', '0.00', '750.00', '0', '0', '750.00', '750.00', '500', '0', '250.00', 'Dues', '4', 1, 1, 1, 1),
(1004, 130, 0, '2020-08-10', '2020-08-10', 'New Badsa', '01751894123', '240.00', '0.00', '240.00', '0', '0', '240.00', '240.00', '240', '0', '0.00', 'Dues', '4', 1, 1, 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `orders_details`
--

CREATE TABLE `orders_details` (
  `id` int(30) NOT NULL,
  `order_id` int(50) NOT NULL,
  `user_id` int(50) NOT NULL,
  `customer_id` int(50) NOT NULL,
  `order_date` date NOT NULL,
  `client_name` varchar(255) NOT NULL,
  `client_contact` varchar(255) NOT NULL,
  `pre_due` varchar(255) NOT NULL,
  `today_total` varchar(255) NOT NULL,
  `grand_total` varchar(255) NOT NULL,
  `paid` varchar(255) NOT NULL,
  `recent_due` varchar(255) NOT NULL,
  `cuses` varchar(200) NOT NULL,
  `order_type` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders_details`
--

INSERT INTO `orders_details` (`id`, `order_id`, `user_id`, `customer_id`, `order_date`, `client_name`, `client_contact`, `pre_due`, `today_total`, `grand_total`, `paid`, `recent_due`, `cuses`, `order_type`) VALUES
(1, 0, 130, 101, '2020-07-18', 'Md.Samiul Alom', '01751458998', '0', '450.00', '450.00', '450', '0.00', 'By Invoice', 1),
(2, 1002, 130, 0, '2020-08-05', 'Kalam', '017518941256', '0', '110.00', '110.00', '50', '60.00', 'By Invoice', 2),
(3, 1003, 130, 104, '2020-08-10', 'Zobayer2', '01611-717527', '0', '750.00', '750.00', '500', '250.00', 'By Invoice', 1),
(4, 1004, 130, 0, '2020-08-10', 'New Badsa', '01751894123', '0', '240.00', '240.00', '240', '0.00', 'By Invoice', 2);

-- --------------------------------------------------------

--
-- Table structure for table `orders_dues`
--

CREATE TABLE `orders_dues` (
  `id` int(11) NOT NULL,
  `order_id` int(30) NOT NULL,
  `user_id` int(15) NOT NULL,
  `customer_id` int(20) NOT NULL,
  `order_date` date NOT NULL,
  `last_update` date NOT NULL,
  `client_name` varchar(255) NOT NULL,
  `client_contact` varchar(255) NOT NULL,
  `pre_due` varchar(500) NOT NULL,
  `today_total` varchar(500) NOT NULL,
  `grand_total` varchar(500) NOT NULL,
  `paid` varchar(240) NOT NULL,
  `recent_due` varchar(500) NOT NULL,
  `dues_or_paid` varchar(30) NOT NULL,
  `dues_or_paid_status` int(50) NOT NULL,
  `cuses` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders_dues`
--

INSERT INTO `orders_dues` (`id`, `order_id`, `user_id`, `customer_id`, `order_date`, `last_update`, `client_name`, `client_contact`, `pre_due`, `today_total`, `grand_total`, `paid`, `recent_due`, `dues_or_paid`, `dues_or_paid_status`, `cuses`) VALUES
(2, 0, 130, 101, '2020-07-18', '2020-07-18', 'Md.Samiul Alom', '01751458998', '0', '450.00', '450.00', '450', '0.00', 'Dues', 5, 'By Invoice'),
(3, 0, 130, 102, '2020-08-05', '2020-08-05', 'New Customer', '01751456623', '0', '0', '0', '0', '0', 'Dues', 4, 'New Customer'),
(4, 1003, 130, 104, '2020-08-10', '2020-08-10', 'Zobayer2', '01611-717527', '0', '750.00', '750.00', '500', '250.00', 'Dues', 4, 'By Invoice');

-- --------------------------------------------------------

--
-- Table structure for table `orders_paid`
--

CREATE TABLE `orders_paid` (
  `id` int(30) NOT NULL,
  `order_id` int(30) NOT NULL,
  `user_id` int(15) NOT NULL,
  `customer_id` int(20) NOT NULL,
  `order_date` date NOT NULL,
  `client_name` varchar(255) NOT NULL,
  `client_contact` varchar(255) NOT NULL,
  `grand_total` varchar(255) NOT NULL,
  `paid` varchar(255) NOT NULL,
  `due` varchar(255) NOT NULL,
  `dues_or_paid` varchar(30) NOT NULL,
  `dues_or_paid_status` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `order_item`
--

CREATE TABLE `order_item` (
  `order_item_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL DEFAULT '0',
  `product_id` int(11) NOT NULL DEFAULT '0',
  `quantity` varchar(255) NOT NULL,
  `rate` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `order_item_status` int(11) NOT NULL DEFAULT '0',
  `buy_rate1` varchar(200) NOT NULL,
  `total_buy_rate` varchar(200) NOT NULL,
  `entry_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_item`
--

INSERT INTO `order_item` (`order_item_id`, `order_id`, `product_id`, `quantity`, `rate`, `total`, `order_item_status`, `buy_rate1`, `total_buy_rate`, `entry_date`) VALUES
(1, 1001, 2001, '5', '50', '250.00', 1, '45', '225', '2020-07-18'),
(2, 1001, 2002, '5', '40', '200.00', 1, '35', '175', '2020-07-18'),
(3, 1002, 2001, '2', '55', '110.00', 1, '45', '90', '2020-08-05'),
(4, 1003, 2003, '5', '120', '600.00', 1, '100', '500', '2020-08-10'),
(5, 1003, 2001, '3', '50', '150.00', 1, '45', '135', '2020-08-10'),
(6, 1004, 2003, '2', '120', '240.00', 1, '100', '200', '2020-08-10');

-- --------------------------------------------------------

--
-- Table structure for table `password`
--

CREATE TABLE `password` (
  `passwordid` int(11) NOT NULL,
  `original` varchar(30) NOT NULL,
  `mdfive` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `password`
--

INSERT INTO `password` (`passwordid`, `original`, `mdfive`) VALUES
(6, 'admin', '21232f297a57a5a743894a0e4a801fc3'),
(130, 'samiul004', 'b17c7f9d339f87ae91c72e08daf1c8db'),
(131, '200710', '8e2945aecfcbf5748ebaf94364eb9807'),
(132, 'omor@2233', '72afd5ae40d11e6b6210e8aa1e048c0c'),
(133, '654321', 'c33367701511b4f6020ec61ded352059'),
(134, '826237', '1aaf3eb3eacb0821c0469b1897acc5d5');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(30) NOT NULL,
  `product_id` int(100) NOT NULL,
  `product_name` varchar(500) NOT NULL,
  `product_image` text NOT NULL,
  `brand_id` int(100) NOT NULL,
  `categories_id` int(100) NOT NULL,
  `quantity` varchar(100) NOT NULL,
  `rate` varchar(255) NOT NULL,
  `retail_rate` varchar(250) NOT NULL,
  `total_rate` varchar(200) NOT NULL,
  `buy_rate` varchar(200) NOT NULL,
  `total_buy_rate` varchar(200) NOT NULL,
  `total_income` varchar(220) NOT NULL,
  `active` int(110) NOT NULL DEFAULT '0',
  `status` int(100) NOT NULL DEFAULT '0',
  `entry_date` date NOT NULL,
  `last_update` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `product_id`, `product_name`, `product_image`, `brand_id`, `categories_id`, `quantity`, `rate`, `retail_rate`, `total_rate`, `buy_rate`, `total_buy_rate`, `total_income`, `active`, `status`, `entry_date`, `last_update`) VALUES
(1, 2001, 'Product 1', '819852.', 0, 0, '100', '50', '55', '5500', '45', '4950', '550', 1, 1, '2020-07-18', '2020-07-20'),
(2, 2002, 'Product 2', '975641.', 0, 0, '115', '40', '45', '4800', '35', '4200', '600', 1, 1, '2020-07-18', '2020-07-18'),
(3, 2003, 'Product 3', '836376.', 0, 0, '113', '120', '0.00', '14400', '100', '12000', '2400', 1, 1, '2020-08-10', '2020-08-10'),
(4, 2004, 'Product 4', '183495.', 0, 0, '50', '150', '0.00', '7500', '140', '7000', '500', 1, 1, '2020-08-10', '2020-08-10');

-- --------------------------------------------------------

--
-- Table structure for table `product_buy`
--

CREATE TABLE `product_buy` (
  `id` int(11) NOT NULL,
  `user_id` int(15) NOT NULL,
  `supplier_id` int(100) NOT NULL,
  `supplier_name` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `invoice_no` varchar(200) NOT NULL,
  `today_total` varchar(500) NOT NULL,
  `pre_due` varchar(500) NOT NULL,
  `grand_total` varchar(500) NOT NULL,
  `paid` varchar(255) NOT NULL,
  `recent_due` varchar(500) NOT NULL,
  `comments` varchar(200) NOT NULL,
  `invoice_date` date NOT NULL,
  `last_update` date NOT NULL,
  `paid_type` varchar(200) NOT NULL,
  `cuses` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `product_buy_details`
--

CREATE TABLE `product_buy_details` (
  `id` int(11) NOT NULL,
  `user_id` int(15) NOT NULL,
  `supplier_id` int(100) NOT NULL,
  `supplier_name` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `invoice_no` varchar(200) NOT NULL,
  `today_total` varchar(500) NOT NULL,
  `pre_due` varchar(500) NOT NULL,
  `grand_total` varchar(500) NOT NULL,
  `paid` varchar(255) NOT NULL,
  `recent_due` varchar(500) NOT NULL,
  `comments` varchar(200) NOT NULL,
  `invoice_date` date NOT NULL,
  `last_update` date NOT NULL,
  `paid_type` varchar(200) NOT NULL,
  `cuses` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `product_depo`
--

CREATE TABLE `product_depo` (
  `id` int(30) NOT NULL,
  `admin_id` int(50) NOT NULL,
  `user_id` int(30) NOT NULL,
  `product_id` varchar(200) NOT NULL,
  `product_name` varchar(200) NOT NULL,
  `brand_id` int(11) NOT NULL,
  `categories_id` int(11) NOT NULL,
  `quantity` int(20) NOT NULL,
  `rate` int(30) NOT NULL,
  `retail_rate` varchar(250) NOT NULL,
  `total_rate` int(30) NOT NULL,
  `buy_rate` int(30) NOT NULL,
  `total_buy_rate` int(30) NOT NULL,
  `total_income` int(30) DEFAULT NULL,
  `status` int(10) NOT NULL,
  `entry_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `product_details`
--

CREATE TABLE `product_details` (
  `id` int(50) NOT NULL,
  `admin_id` varchar(150) NOT NULL,
  `user_id` varchar(150) NOT NULL,
  `product_id` varchar(200) NOT NULL,
  `product_name` varchar(500) NOT NULL,
  `brand_id` int(30) NOT NULL,
  `categories_id` int(30) NOT NULL,
  `quantity` varchar(200) NOT NULL,
  `add_qty` varchar(200) NOT NULL,
  `total_qty` varchar(200) NOT NULL,
  `total_qty_price` varchar(200) NOT NULL,
  `rate` varchar(200) NOT NULL,
  `retail_rate` varchar(250) NOT NULL,
  `total_rate` varchar(200) NOT NULL,
  `buy_rate` varchar(200) NOT NULL,
  `total_buy_rate` varchar(200) NOT NULL,
  `total_income` varchar(200) DEFAULT NULL,
  `cuses` varchar(300) NOT NULL,
  `entry_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_details`
--

INSERT INTO `product_details` (`id`, `admin_id`, `user_id`, `product_id`, `product_name`, `brand_id`, `categories_id`, `quantity`, `add_qty`, `total_qty`, `total_qty_price`, `rate`, `retail_rate`, `total_rate`, `buy_rate`, `total_buy_rate`, `total_income`, `cuses`, `entry_date`) VALUES
(1, '22', '22', '2001', 'Product 1', 0, 0, '100', '0', '0', '0', '50', '55', '5000', '45', '4500', '500', 'Admin Stock', '2020-07-18'),
(2, '22', '22', '2002', 'Product 2', 0, 0, '120', '0', '0', '0', '40', '45', '4800', '35', '4200', '600', 'Admin Stock', '2020-07-18'),
(3, '22', '22', '2001', 'Product 1', 0, 0, '100', '10', '110', '500', '50', '55', '5500', '45', '4950', '550', 'Admin Stock', '2020-07-18'),
(4, '22', '22', '2001', 'Product 1', 0, 0, '105', '0', '105', '5500', '50', '55', '5500', '45', '4950', '550', 'Edit', '2020-07-20'),
(5, '22', '22', '2001', 'Product 1', 0, 0, '105', '0', '105', '5500', '50', '55', '5500', '45', '4950', '550', 'Edit', '2020-07-20'),
(6, '22', '22', '2003', 'Product 3', 0, 0, '100', '0', '0', '0', '120', '0.00', '12000', '100', '10000', '2000', 'Admin Stock', '2020-08-10'),
(7, '22', '22', '2003', 'Product 3', 0, 0, '100', '20', '120', '2400', '120', '0.00', '14400', '100', '12000', '2400', 'Admin Stock', '2020-08-10'),
(8, '22', '22', '2004', 'Product 4', 0, 0, '0', '50', '50', '0', '150', '0.00', '7500', '140', '7000', '500', 'Admin Stock', '2020-08-10');

-- --------------------------------------------------------

--
-- Table structure for table `product_transfer`
--

CREATE TABLE `product_transfer` (
  `id` int(50) NOT NULL,
  `admin_id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `product_id` varchar(200) NOT NULL,
  `product_name` varchar(500) NOT NULL,
  `brand_id` int(30) NOT NULL,
  `categories_id` int(30) NOT NULL,
  `quantity` varchar(200) NOT NULL,
  `add_qty` varchar(200) NOT NULL,
  `total_qty` varchar(200) NOT NULL,
  `total_qty_price` varchar(200) NOT NULL,
  `rate` varchar(200) NOT NULL,
  `total_rate` varchar(200) NOT NULL,
  `buy_rate` varchar(200) NOT NULL,
  `total_buy_rate` varchar(200) NOT NULL,
  `total_income` varchar(200) DEFAULT NULL,
  `entry_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sales_return`
--

CREATE TABLE `sales_return` (
  `id` int(50) NOT NULL,
  `admin_id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `chalan_no` varchar(250) NOT NULL,
  `product_id` varchar(200) NOT NULL,
  `product_name` varchar(500) NOT NULL,
  `brand_id` int(30) NOT NULL,
  `categories_id` int(30) NOT NULL,
  `quantity` varchar(200) NOT NULL,
  `add_qty` varchar(200) NOT NULL,
  `total_qty` varchar(200) NOT NULL,
  `total_qty_price` varchar(200) NOT NULL,
  `rate` varchar(200) NOT NULL,
  `total_rate` varchar(200) NOT NULL,
  `buy_rate` varchar(200) NOT NULL,
  `total_buy_rate` varchar(200) NOT NULL,
  `total_income` varchar(200) DEFAULT NULL,
  `entry_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sales_return`
--

INSERT INTO `sales_return` (`id`, `admin_id`, `user_id`, `chalan_no`, `product_id`, `product_name`, `brand_id`, `categories_id`, `quantity`, `add_qty`, `total_qty`, `total_qty_price`, `rate`, `total_rate`, `buy_rate`, `total_buy_rate`, `total_income`, `entry_date`) VALUES
(315, 131, 131, '1', '1025', 'Y330', 0, 0, '11', '10', '21', '13500', '1350', '28350', '70', '1470', '26880', '2020-03-08');

-- --------------------------------------------------------

--
-- Table structure for table `stuff`
--

CREATE TABLE `stuff` (
  `userid` int(11) NOT NULL,
  `stuff_name` varchar(50) NOT NULL,
  `position` varchar(500) NOT NULL,
  `contact_info` varchar(50) NOT NULL,
  `photo` varchar(150) NOT NULL,
  `join_date` date NOT NULL,
  `status` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stuff`
--

INSERT INTO `stuff` (`userid`, `stuff_name`, `position`, `contact_info`, `photo`, `join_date`, `status`) VALUES
(22, 'Admin', 'Admin', 'Admin', '212', '2020-03-22', 0),
(130, 'Samiul ITM', 'User ', '01751891037', 'upload/computer_icon_1581486929.png', '2019-07-10', 1),
(131, 'romel', 'Show Room 2', '01746895819', '', '0000-00-00', 0),
(132, 'FARUK', 'Collection', '01742078781', '', '0000-00-00', 0),
(133, 'ABU ZIHAD', 'Show Room 3  ', '01719826237', '', '2020-02-23', 0),
(134, 'mozahid', 'Collector  ', '01794776083', '', '2020-03-03', 0);

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `supplier_id` int(30) NOT NULL,
  `user_id` int(100) NOT NULL,
  `supplier_no` int(230) NOT NULL,
  `supplier_name` varchar(500) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `address` varchar(500) NOT NULL,
  `contact_info` varchar(100) NOT NULL,
  `national_id` varchar(200) NOT NULL,
  `join_date` date NOT NULL,
  `status` int(10) NOT NULL,
  `userPic` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `title_name`
--

CREATE TABLE `title_name` (
  `id` int(10) NOT NULL,
  `location` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `stutas` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `title_name`
--

INSERT INTO `title_name` (`id`, `location`, `name`, `stutas`) VALUES
(2, 'Header', 'ITM SALES MANAGEMENT', 0),
(5, 'Title Bar', 'ITM SALES MANAGEMENT', 0),
(6, 'Report Title', 'ITM SALES MANAGEMENT', 0);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `userid` int(11) NOT NULL,
  `full_name` varchar(250) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `access_level` int(11) NOT NULL,
  `status` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userid`, `full_name`, `username`, `password`, `access_level`, `status`) VALUES
(22, 'Admin', 'admin', '0192023a7bbd73250516f069df18b500', 1, 1),
(130, 'Samiul ITM', 'samiul004', 'b17c7f9d339f87ae91c72e08daf1c8db', 4, 1),
(131, 'romel', 'romel', '8e2945aecfcbf5748ebaf94364eb9807', 4, 1),
(132, 'FARUK', 'FARUK', '72afd5ae40d11e6b6210e8aa1e048c0c', 4, 1),
(133, 'ABU ZIHAD', 'abuzihad', 'c33367701511b4f6020ec61ded352059', 4, 1),
(134, 'mozahid', 'mozahid', '1aaf3eb3eacb0821c0469b1897acc5d5', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `userlog`
--

CREATE TABLE `userlog` (
  `userlogid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `login` datetime NOT NULL,
  `logout` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activitylog`
--
ALTER TABLE `activitylog`
  ADD PRIMARY KEY (`activitylog`);

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`brand_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`categories_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `expense`
--
ALTER TABLE `expense`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `orders_details`
--
ALTER TABLE `orders_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders_dues`
--
ALTER TABLE `orders_dues`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders_paid`
--
ALTER TABLE `orders_paid`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_item`
--
ALTER TABLE `order_item`
  ADD PRIMARY KEY (`order_item_id`);

--
-- Indexes for table `password`
--
ALTER TABLE `password`
  ADD PRIMARY KEY (`passwordid`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`id`),
  ADD KEY `product_id_2` (`id`);

--
-- Indexes for table `product_buy`
--
ALTER TABLE `product_buy`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_buy_details`
--
ALTER TABLE `product_buy_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_depo`
--
ALTER TABLE `product_depo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_details`
--
ALTER TABLE `product_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_transfer`
--
ALTER TABLE `product_transfer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sales_return`
--
ALTER TABLE `sales_return`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stuff`
--
ALTER TABLE `stuff`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`supplier_id`);

--
-- Indexes for table `title_name`
--
ALTER TABLE `title_name`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `userlog`
--
ALTER TABLE `userlog`
  ADD PRIMARY KEY (`userlogid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activitylog`
--
ALTER TABLE `activitylog`
  MODIFY `activitylog` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=627;
--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `brand_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;
--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `categories_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;
--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `customer_id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=105;
--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `expense`
--
ALTER TABLE `expense`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1005;
--
-- AUTO_INCREMENT for table `orders_details`
--
ALTER TABLE `orders_details`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `orders_dues`
--
ALTER TABLE `orders_dues`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `orders_paid`
--
ALTER TABLE `orders_paid`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `order_item`
--
ALTER TABLE `order_item`
  MODIFY `order_item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `password`
--
ALTER TABLE `password`
  MODIFY `passwordid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=135;
--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `product_buy`
--
ALTER TABLE `product_buy`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `product_buy_details`
--
ALTER TABLE `product_buy_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `product_depo`
--
ALTER TABLE `product_depo`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `product_details`
--
ALTER TABLE `product_details`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `product_transfer`
--
ALTER TABLE `product_transfer`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `sales_return`
--
ALTER TABLE `sales_return`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=316;
--
-- AUTO_INCREMENT for table `supplier`
--
ALTER TABLE `supplier`
  MODIFY `supplier_id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=132;
--
-- AUTO_INCREMENT for table `title_name`
--
ALTER TABLE `title_name`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=135;
--
-- AUTO_INCREMENT for table `userlog`
--
ALTER TABLE `userlog`
  MODIFY `userlogid` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
