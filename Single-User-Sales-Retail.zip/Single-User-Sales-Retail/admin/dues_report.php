<?php require_once 'header.php'; ?>
<link rel="stylesheet" href="css/buttons.css">
	
<center><h3><ol class="breadcrumb"> <li class="active"> Dues Reports</li></ol></h3>	</center>
	<div class="buttons">
	
		<div class="col-md-6">
		<a class="btn btn-success" style="width:100%" href="ReportDues.php"> <span class="glyphicon glyphicon-file"></span> Date Wise ( All ) </a> 
		</div>
		
		<div class="col-md-6">
		<a class="btn btn-success" style="width:100%" href="dues_report_short.php"> <span class="glyphicon glyphicon-file"></span> Date Wise ( Short ) </a> 
		</div>

		<div class="col-md-6">
		<a class="btn btn-success"  style="width:100%" href="dues_report_details.php"> <span class="glyphicon glyphicon-file"></span>  Date Wise ( Details )</a> 
		</div>
		
		<div class="col-md-6">
		<a class="btn btn-success"  style="width:100%" href="dues_report_details_single.php"> <span class="glyphicon glyphicon-file"></span> Details Report ( Single ) </a> 
		</div>
		
		</div>

<?php //require_once 'includes/footer.php'; ?>