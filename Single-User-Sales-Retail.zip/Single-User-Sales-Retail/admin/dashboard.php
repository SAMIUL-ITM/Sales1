<?php require_once 'header.php'; ?> 

<style> a{font-size:17px; color:black;} .badge{font-size:17px;} </style>
<div class="row">
	<div class="col-md-2">
		<div class="panel panel-success">
			<div class="panel-heading">
				
				<a  href="customer.php" >
					Total Customer
					<span class="badge pull pull-right">
<?php 
$sql = $con->query("SELECT count(`customer_id`) as `gtotal` FROM `customer` where status=1 ");
$row = $sql->fetch_assoc();
echo $row['gtotal'];
?>
					</span>
				</a>
				
			</div> <!--/panel-hdeaing-->
		</div> <!--/panel-->
	</div> <!--/col-md-4-->
	
	<div class="col-md-3">
		<div class="panel panel-danger">
			<div class="panel-heading">
				<a  href="dues_recent.php" >
					Total Due Customer
					<span class="badge pull pull-right">
<?php 
$sql = $con->query("SELECT count(`customer_id`) as `gtotal` FROM `orders_dues` where recent_due !=0 ");
$row = $sql->fetch_assoc();
echo $row['gtotal'];
?>
					</span>
				</a>
				
			</div>  
		</div>  
	</div>  
	
	<div class="col-md-2">
			<div class="panel panel-info">
			<div class="panel-heading">
			<a  href="orders.php?o=manord" >
					Invoice List
					<span class="badge pull pull-right">
					<?php 
$sql = $con->query("SELECT count(`order_id`) as `gtotal` FROM `orders` ");
$row = $sql->fetch_assoc();
echo $row['gtotal'];
?>
					</span>	
				</a>
		</div> <!--/panel-hdeaing-->
		</div> <!--/panel-->
		</div> <!--/col-md-4-->
	
	<div class="col-md-2">
		<div class="panel panel-danger">
			<div class="panel-heading">
				<a href="productN.php" >
			   Product List
				<span class="badge pull pull-right">
				<?php 
$sql = $con->query("SELECT count(`id`) as `gtotal` FROM `product` ");
$row = $sql->fetch_assoc();
echo $row['gtotal'];
?>
				</span>						
				</a>
				
			</div> <!--/panel-hdeaing-->
		</div> <!--/panel-->
	</div> <!--/col-md-4-->
	
	<div class="col-md-3">
		<div class="panel panel-danger">
			<div class="panel-heading">
				<a  href="Report.php" >
					All Report
					<span class="badge pull pull-right">
					Click
					</span>						
				</a>
				
			</div> <!--/panel-hdeaing-->
		</div> <!--/panel-->
	</div> <!--/col-md-4-->
	

	<div class="col-md-4">
		<div class="card">
		  
		  <div class="cardHeader">
		    <h3><?php include('../includes/header_title.php'); ?><br>..............................<br><i class="fa fa-clock-o fa-fw"></i> <?php include('time.php'); ?></center></h3>
		  </div>

		  <div class="cardContainer">
		    <p><h3><?php
        $date = new DateTime();
        echo $date->format('l -- F j, Y');
    ?></h3></p>
		    
		  </div>
		</div> 
		<br/>

		
		
		<div class="card">
		  <div class="cardHeader" style="background-color:#245580;">
		    <img src="../includes/itm.png" alt="" />
		  </div>

		  <div class="cardContainer">
			<p>Design & Developed By <a  href="https://itmsofts.com/">ITM-SOFTS</a></p>
		  </div>
		</div> 

	</div>

	<div class="col-md-8">
		<div class="panel panel-default">
			
			<div class="panel-body">
				<div id="calendar"><center><img src="../includes/itmm.jpg" width="100%"  /></div>
			</div>	
		</div>
		
	</div>
</div> <!--/row-->

<script src="custom/js/order.js"></script>
<?php include('modal.php'); ?>
<?php include('../includes/footer.php'); ?>
