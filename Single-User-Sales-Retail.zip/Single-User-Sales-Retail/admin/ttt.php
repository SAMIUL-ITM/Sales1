
<?php include('php_action/view_product_stock.php'); ?>
