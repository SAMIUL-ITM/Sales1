<?php require_once 'header.php'; ?>
<link rel="stylesheet" href="css/buttons.css">
	
<center><h3><ol class="breadcrumb"> <li class="active">Sales  Report</li></ol></h3>	</center>

<div class="buttons col-md-3">
	
	<div class="panel-heading">
	<center><h3><ol class="breadcrumb"> <li class="active">Sales  Report ( All ) </li></ol></h3>	</center>
	</div>
	    
        <div class="panel-heading">
		<a  class="btn btn-success" style="width:100%" href="sales_report_by_date_short.php"> <span class="glyphicon glyphicon-print"></span> Daily Sales Report </a> 
		</div>  
		
		<div class="panel-heading">
		<a  class="btn btn-success"  style="width:100%" href="sales_report_by_single_cust.php"> <span class="glyphicon glyphicon-print"></span> Customer Statement  ( All ) </a> 
		</div>
		
		<div class="panel-heading">
		<a  class="btn btn-success"  style="width:100%" href="retail_cust_statement.php"> <span class="glyphicon glyphicon-print"></span> Customer Statement  ( Retail ) </a> 
		</div>
		
		<div class="panel-heading">
		<a  class="btn btn-success"  style="width:100%" href="sales_report_single_cust_by_date.php"> <span class="glyphicon glyphicon-print"></span> Customer Statement ( By Date )</a> 
		</div>
		
		
		<div class="panel-heading">
		<a  class="btn btn-success" style="width:100%" href="CollReportShort.php"> <span class="glyphicon glyphicon-print"></span> Collection Report ( Short ) </a> 
		</div>
		
		<div class="panel-heading">
		<a  class="btn btn-success" style="width:100%" href="CollReportDetails.php"> <span class="glyphicon glyphicon-print"></span> Collection Report ( Details ) </a> 
		</div>
</div>
		
		
<div class="buttons col-md-3" style="display:none;" >
	<div class="panel-heading">
	<center><h3><ol class="breadcrumb"> <li class="active"> Sales  Report  ( User Wise )</li></ol></h3>	</center>
	</div>
	    
		<div class="panel-heading">
		<a  class="btn btn-success" style="width:100%" href="DailySalesReportUser.php"> <span class="glyphicon glyphicon-print"></span> Daily Sales Report </a> 
		</div>
		
	    <div class="panel-heading">
		<a  class="btn btn-success" style="width:100%" href="CollReportShortUser.php"> <span class="glyphicon glyphicon-print"></span> Collection Report ( Short ) </a> 
		</div>
		
		<div class="panel-heading">
		<a  class="btn btn-success" style="width:100%" href="CollReportDetailsUser.php"> <span class="glyphicon glyphicon-print"></span> Collection Report ( Details ) </a> 
		</div>
		
		<div class="panel-heading">
		<a  class="btn btn-success" style="width:100%" href="prft_rpt_by_date_user.php"> <span class="glyphicon glyphicon-print"></span> Product  Buy-Sales / Profit</a> 
		</div>
		
		<div class="panel-heading">
		<a  class="btn btn-success" style="width:100%" href="prft_rpt_by_date_short_user.php"> <span class="glyphicon glyphicon-print"></span> Product  Buy-Sales / Profit  ( Sort )  </a> 
		</div>
		
		<div class="panel-heading">
		<a  class="btn btn-success" style="width:100%" href="daily_product_sales_user.php"> <span class="glyphicon glyphicon-file"></span> Daily Product Sale - Item Wise </a> 
		</div>
		
</div>
		

		
		<div class="buttons col-md-3">
	<div class="panel-heading">
	<center><h3><ol class="breadcrumb"> <li class="active">Daily Report</li></ol></h3>	</center>
	</div>
		
	<!--	<div class="panel-heading">
		<a  class="btn btn-success" style="width:100%" href="ReportDues.php"> <span class="glyphicon glyphicon-file"></span> Collection Report All </a> 
		</div>
		-->
		
	<div class="panel-heading">
		<a  class="btn btn-success" style="width:100%" href="daily_report11.php"> <span class="glyphicon glyphicon-file"></span> Daily Report </a> 
		</div>
	<!--	
		<div class="panel-heading">
		<a  class="btn btn-success" style="width:100%" href="daily_report_by_date.php"> <span class="glyphicon glyphicon-file"></span> Daily Report (Date   Wise ) </a> 
		</div>  -->	
		
		<div class="panel-heading">
		<a  class="btn btn-success" style="width:100%" href="income.php"> <span class="glyphicon glyphicon-file"></span> Product  Buy-Sales / Profit</a> 
		</div>
		
		<div class="panel-heading">
		<a  class="btn btn-success" style="width:100%" href="daily_product_sales.php"> <span class="glyphicon glyphicon-file"></span> Daily Product Sale - Item Wise </a> 
		</div>
		
		</div>
	<!--	
	<div class="buttons col-md-3">
	<div class="panel-heading">
	<center><h3><ol class="breadcrumb"> <li class="active">Others Report</li></ol></h3>	</center>
	</div>
		<div class="panel-heading">
		<a  class="btn btn-success" style="width:100%" href="sales_report_delivery_product.php"> <span class="glyphicon glyphicon-file"></span> Delivery Product</a> 
		</div>
		</div>
-->	
</div>

<?php //require_once '../includes/footer.php'; ?>